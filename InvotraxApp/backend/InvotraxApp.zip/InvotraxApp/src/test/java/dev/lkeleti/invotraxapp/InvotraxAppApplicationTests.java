package dev.lkeleti.invotraxapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvotraxAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
