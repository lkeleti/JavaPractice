package dev.lkeleti.invotraxapp.repository;

import dev.lkeleti.invotraxapp.model.Partner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartnerRepository extends JpaRepository<Partner, Long> {

}